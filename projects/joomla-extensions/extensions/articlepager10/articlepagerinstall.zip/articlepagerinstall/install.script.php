<?php
/*
* @name article pager 1.0
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/
defined ( '_JEXEC' ) or die ();

jimport('joomla.installer.helper');
$installer = new JInstaller();
//$installer->_overwrite = true;

$pkg_path = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_articlepagerinstall'.DS.'extensions'.DS;
$pkgs = array( 'com_articlepager.zip'=>'Component',
               'plg_articlepager.zip'=>'Plugin',
			   'plg_articlepager_admin.zip'=>'Plugin'
             );

$errore=0;
foreach( $pkgs as $pkg => $pkgname ):
  $package = JInstallerHelper::unpack( $pkg_path.$pkg );
  if( $installer->install( $package['dir'] ) )
  {
    $msgcolor = "#E0FFE0";
    $msgtext  = "$pkgname successfully installed.";
  }
  else
  {
	$errore=1;
    $msgcolor = "#FFD0D0";
    $msgtext  = "ERROR: Could not install the $pkgname. Please install manually.";
  }
  ?>
  <table bgcolor="<?php echo $msgcolor; ?>" width ="100%">
    <tr style="height:30px">
      <td width="50px"><img src="/administrator/images/tick.png" height="20px" width="20px"></td>
      <td><font size="2"><b><?php echo $msgtext; ?></b></font></td>
    </tr>
  </table>
<?php
JInstallerHelper::cleanupInstall( $pkg_path.$pkg, $package['dir'] ); 
endforeach;

/*$base=explode("administrator/",JURI::base());*/

$database = JFactory::getDBO();
$database->setQuery("UPDATE #__extensions SET enabled=1 WHERE element='articlepageradmin' OR element='articlepager'");
$database->query();
?>

<!--<div style="width:270px; text-align:center; padding:10px; margin-top:20px; background:#ffc700; -webkit-border-radius: 15px; -moz-border-radius: 15px; border-radius: 15px;">
	<a href="<?php echo $base[0]; ?>?option=com_socialchatcore&install=1" style="font-weight:bold; font-size:15px;">Click to complete the installation</a>
</div>-->