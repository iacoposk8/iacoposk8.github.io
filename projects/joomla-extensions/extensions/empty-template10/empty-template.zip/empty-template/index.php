<?php
/**
 * @version		Empty Template 1.0
 * @copyright	Copyright (C) 2011 Joomla Zone.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

$liquid= $this->params->get('liquid');
if($liquid==""){$liquid=1;}

if($liquid==0){$liquid="default";}
if($liquid==1){$liquid="liquid";}
?>
<?php echo '<?'; ?>xml version="1.0" encoding="<?php echo $this->_charset ?>"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >
<head>
	<jdoc:include type="head" />
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/<?php echo $liquid; ?>.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/style_mobile.css" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/style_tablet.css" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >

	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	<div id="mainWrapper">
		<div id="topWrapper">
		<?php if($this->countModules('top')) : ?>
			<div id="top">
  	 			<jdoc:include type="modules" name="top" style="xhtml"/>
			</div>
		<?php endif; ?>
		</div>
		
		<?php if($this->countModules('left')) : ?>
			<div id="left" class="sidebar">
				<jdoc:include type="modules" name="left" style="xhtml"/>
			</div>
		<?php endif; ?>
		
		<?php
			if(!$this->countModules('left') || !$this->countModules('right')){$larghezza_main="one_column";}//c'� solo una colonna
			if(!$this->countModules('left') && !$this->countModules('right')){$larghezza_main="no_column";}//non ci sono colonne
			if($this->countModules('left') && $this->countModules('right')){$larghezza_main="two_column";}//ci sono 2 colonne
		?>
		
		<div id="main" class="<?php echo $larghezza_main; ?>">
			<jdoc:include type="message" />
			<jdoc:include type="component" />				  	 			
		</div>
		<?php if($this->countModules('right')) : ?>
			<div id="right" class="sidebar">
				<jdoc:include type="modules" name="right" style="xhtml"/>
			</div>
		<?php endif; ?>
	</div>			
	
	<?php if($this->countModules('footer')) : ?>
		<div id="footer">
			<jdoc:include type="modules" name="footer" style="xhtml"/>
		</div>
	<?php endif; ?>
	<p style="font-size:10px; text-align:center;">Powered by <a href="http://www.iacopo-guarneri.me/" target="_blank">Iacopo Guarneri</a></p>
</body>
</html>
