<?php
/*
* @name article pager 1.0
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/
defined ( '_JEXEC' ) or die ();

jimport('joomla.installer.helper');
$installer = new JInstaller();

$pkg_path=dirname(__FILE__).DIRECTORY_SEPARATOR."extensions".DIRECTORY_SEPARATOR;
$pkgs = array('com_forumtranslator.zip', 'mod_forumtranslator.zip');

for($i=0; $i<count($pkgs); $i++){
	$package = JInstallerHelper::unpack( $pkg_path.$pkgs[$i] );
	if(!$installer->install($package['dir'])){
		//error
	}
}

$base=explode("administrator/",JURI::base());
$url='<a href="'.$base[0].'index.php?option=com_forumtranslator&install=1">Click to complete the installation</a>';
JError::raiseNotice( 100, $url);
?>