<?php

/*
* @name html5player 1.0
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );

class plgContenthtml5player extends JPlugin
{
	function onContentPrepare( $context, &$article, &$params, $limitstart=0 ) {
		$pxperc = $this->params->get('pxperc', "%");
		$width = $this->params->get('width', 100);
			if($width==0)
				$width="auto";
			else
				$width.=$pxperc;
		$height = $this->params->get('height', 0);
			if($height==0)
				$height="auto";
			else
				$height.=$pxperc;
		$background = $this->params->get('background', "0");
			if($background==="0")
				$background="none";

		$lists=array("audio","video");
		foreach($lists as $list){
			$elem="";
	      		if (strpos($article->text, '[html5'.$list )){
				$elem=$list;
			}else{
	  			continue;
			}
			preg_match_all('/\[html5'.$elem.'(.*?)\]/ims',$article->text,$codes);
			foreach($codes[1] as $code){ 
				preg_match_all('/source="(.*?)"/ims',$code,$source);
				$source=$source[1][0];
				if(strpos($source, ','))
					$source=explode(",",$source);
				else
					$source=array($source);

				$autoplay="";
				if(strstr($code,"autoplay"))
					$autoplay=" autoplay";
				
				preg_match_all('/poster="(.*?)"/ims',$code,$poster);
				$poster_attr="";
				if(isset($poster[1][0]))
					$poster_attr=' poster="'.$poster[1][0].'"';

				$return='<'.$elem.$autoplay.$poster_attr.' controls style="width:'.$width.'; height:'.$height.'; background:'.$background.';">';
				foreach($source as $s){
					$ext=explode(".",$s);
					if(strtolower($ext[count($ext)-1])=="mp3")
						$type="audio/mpeg";
					if(strtolower($ext[count($ext)-1])=="ogg")
						$type="audio/ogg";
					if(strtolower($ext[count($ext)-1])=="wav")
						$type="audio/wav";
					if(strtolower($ext[count($ext)-1])=="mp4")
						$type="video/mp4";
					if(strtolower($ext[count($ext)-1])=="webm")
						$type="video/webm";
					if(strtolower($ext[count($ext)-1])=="ogg")
						$type="video/ogg";

		  			$return.='<source src="'.$s.'" type="'.$type.'">';
				}
				$return.='Your browser does not support the '.$elem.' element.</'.$elem.'>';

				$article->text= preg_replace('/\[html5'.$elem.'(.*?)\]/',$return, $article->text,1);
			} 
		}
   		return true;
  	}
}
