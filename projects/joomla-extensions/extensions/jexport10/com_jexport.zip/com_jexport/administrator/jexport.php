<?php
/*------------------------------------------------------------------------
# com_jexport - JExport
# ------------------------------------------------------------------------
# Iacopo Guarneri
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.iacopo-guarneri.me
-------------------------------------------------------------------------*/
	// no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' ); 

	//requirements: symlink, file_get_contents, timeout
	
	//error_reporting(E_ALL);
	//ini_set("display_errors", 1);
	ini_set('xdebug.max_nesting_level', 99999999999999999);
	ini_set('max_execution_time', 0);

class Export{
	private $url;
	private $path;
	public $rules = array();
	public $absolute="components/com_jexport/export/";
	private $extension = array("html","php","no extension");
	private $scanned = array();
	public $oneurl=false;

	private function isSecure() {
	  return
	    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
	    || $_SERVER['SERVER_PORT'] == 443;
	}
	public function Export(){
		if($this->isSecure())
			$this->url="https://$_SERVER[HTTP_HOST]";
		else
			$this->url="http://$_SERVER[HTTP_HOST]";
		
		$path = explode($this->url,JURI::base());
		$path = str_replace('/administrator','',$path[1]);
		if(substr($path,0,1)=="/")
			$path=substr($path,1);
		if(substr($path,-1,1)=="/")
			$path=substr($path,0,strlen($path)-1);
		$this->path=$path;

		@mkdir($this->absolute);
	}
	
	public function init(){
		@mkdir($this->absolute);
		$scan=explode("administrator",__dir__);
		$dirs=scandir($scan[0]);
		foreach($dirs as $dir){
			if(is_dir($scan[0].$dir) && $dir!="." && $dir!=".." && $dir!="__MACOSX" && !file_exists($this->absolute.$dir))
				@symlink($scan[0].$dir, $this->absolute.$dir);
		}
	}
	
	public function set_rules($rules){
		if(strstr($rules,"\n"))
			$rules=explode("\n",$rules);
		else
			$rules=array($rules);
		foreach($rules as $rule){
			$ins_r=explode(",",$rule);
			$this->rules[]=array(trim($ins_r[0]),trim($ins_r[1]));
		}
	}
	
	private function Path($p){
		$a = explode ("/", $p);
		$len = strlen ($a[count ($a) - 1]);
		return (substr ($p, 0, strlen ($p) - $len));
	}
	private function get_web_page( $url ){
	    $options = array(
		CURLOPT_RETURNTRANSFER => true,     // return web page
		CURLOPT_HEADER         => false,    // don't return headers
		CURLOPT_FOLLOWLOCATION => true,     // follow redirects
		CURLOPT_ENCODING       => "",       // handle all encodings
		CURLOPT_USERAGENT      => "spider", // who am i
		CURLOPT_AUTOREFERER    => true,     // set referer on redirect
		CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
		CURLOPT_TIMEOUT        => 120,      // timeout on response
		CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
		CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
	    );

	    $ch      = curl_init( $url );
	    curl_setopt_array( $ch, $options );
	    $content = curl_exec( $ch );
	    $err     = curl_errno( $ch );
	    $errmsg  = curl_error( $ch );
	    $header  = curl_getinfo( $ch );
	    curl_close( $ch );

	    $header['errno']   = $err;
	    $header['errmsg']  = $errmsg;
	    $header['content'] = $content;
	    return $content;
	}
	private function GetUrl($url){
		/*$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
		$data = curl_exec($ch);
		curl_close($ch);
		if($data)
			return $data;
		else*/
		
		return $this->get_web_page($url);
		//return @file_get_contents($url);
	}
	private function get_file_name($href){
		$elem=1;
		//se ci sono 2 index.php
		if(strstr(str_replace("index.php","",$href,$elem),"index.php"))
			@$filename=$filename[count($filename)-2].".html";
		else{
			$filename=explode("/",$href);
			@$filename=$filename[count($filename)-1].".html";
		}
		
		if($filename=="index.php.html")
			$filename="index.html";
		if($filename==".html")
			$filename="index.html";
		
		$filename=preg_replace('/[^A-Za-z0-9\-\.]/', '', $filename);
		return str_replace($this->path,"",$filename);
	}

	public function Scan($url=""){
		if($url==""){
			$url=explode("/administrator",JURI::base());
			$url=$url[0];
		}

		echo "Scan url $url <br />";

		array_push ($this->scanned, $url);
		$html_origin = $this->GetUrl($url); //die(var_dump($html_origin));
		$html = preg_replace('/<script(.*?)>(.*?)<\/script>/ims','',$html_origin);
		
		preg_match_all('/<a(.*?)href="(.*?)"/ims',$html,$a1_1);
		preg_match_all('/<a(.*?)href="(.*?)"/ims',$html,$a1_2);
		preg_match_all("/<a(.*?)href='(.*?)'/ims",$html,$a1_3);
		$a1=array_merge($a1_1[2],$a1_2[2]);
		$a1=array_merge($a1,$a1_3[2]);

		foreach ($a1 as $hrefparts){
			$hrefparts2 = explode ("#", str_replace($this->path,"",$hrefparts));
			$href = str_replace ("\"", "", $hrefparts2[0]);
			$href=str_replace("//","/",$href);
			$href=str_replace("http:/","http://",$href);
			$href=str_replace("https:/","https://",$href);
			
			if(
				strstr(strtolower($href),"javascript:") ||
				strstr(strtolower($href),"<iframe")
			){
				continue;
			}

			if ((substr ($href, 0, 7) != "http://") && 
			   (substr ($href, 0, 8) != "https://") &&
			   (substr ($href, 0, 6) != "ftp://")){
				if (@$href[0] == '/'){
					$href = $this->scanned[0].$href;
				}else{
					$href = $this->Path($url) . $href;
				}
			}
	
			//remove last slash
			if($href[strlen($href)-1]=="/")
				$href=substr($href,0,-1);

			if (substr ($href, 0, strlen ($this->scanned[0])) == $this->scanned[0]){
				$ignore = false;
				/*if (isset ($skip))
				foreach ($skip as $k => $v)
					if (substr ($href, 0, strlen ($v)) == $v)
					$ignore = true;*/
			
				//check extension
				$url2=parse_url($href);
				$url2=$url2["path"];
				if(strstr($url2,"/")){
					$url2=explode("/",$url2);
					$url2=$url2[count($url2)-1];
				}
				if(strstr($url2,".")){
					$ext=explode(".",$url2);
					$ext=$ext[count($ext)-1];
				}else
					$ext="no extension"; 
				//end check extension

				if ((!$ignore) &&
				(!in_array ($href, $this->scanned)) && 
				(in_array($ext, $this->extension))		
				){
					$var=fopen($this->absolute.$this->get_file_name($href),"w");
					//echo $this->get_file_name($href)."<br />";
					
					$cont=preg_replace('/\<base href="(.*?)" \/\>/',"",$this->GetUrl($href));
					$cont=preg_replace('/\<meta content\="(.*?)" property\="og\:url" \/\>/',"",$cont);
					$cont=preg_replace("/var onePageUrl \= '\/".$this->path."'\;/","var onePageUrl = '.';",$cont);
					
					//user rules
					foreach($this->rules as $rule){
						if(str_replace(" ","",$rule[0])!=""){
							$cont=preg_replace($rule[0],$rule[1],$cont);
						}
					}
					
					$cont=str_replace($url."/","",$cont);
					if($this->path!="")
						$cont=str_replace("/".$this->path."/","",$cont);
					
					//menu
					preg_match_all("/\<a(.*?)href\=\"(.*?)index\.php(.*?)\"(.*?)\>/ims", $cont, $matches);
					foreach($matches[3] as $match){
						if(!strstr($cont,'index.php'.$match.'"'))
							$match=urlencode($match);
						$cont=str_replace('index.php'.$match.'"', $this->get_file_name($match).'"',$cont);
					}
					preg_match_all('/\<a(.*?)href\=\'(.*?)index\.php(.*?)\'(.*?)\>/ims', $cont, $matches);
					foreach($matches[3] as $match){
						if(!strstr($cont,'index.php'.$match.'"'))
							$match=urlencode($match);
						$cont=str_replace("index.php".$match."'", $this->get_file_name($match)."'",$cont);
					}
					
					//$cont=str_replace('href="#','href="index.html#',$cont);
					
					fwrite($var, $cont);

					if($this->oneurl===true)
						return false;
					$this->Scan($href);
				}
			}
		}
	}
}

$application = JFactory::getApplication();
$document = JFactory::getDocument();
$document->addStyleDeclaration('
#rules{
	height:250px;
	width:90%;
}
.cols{
	overflow:hidden;
}
.col{
	float:left;
	width:50%;
}
#path{
	font-size:20px;
}
');

$txt_view_export=JText::_('COM_JEXPORT_VIEW_EXPORT');
$txt_hours=JText::_('COM_JEXPORT_HOURS');
$txt_minuts=JText::_('COM_JEXPORT_MINUTS');
$txt_second=JText::_('COM_JEXPORT_SECOND');
$txt_export=JText::_('COM_JEXPORT_EXPORT');
$txt_rule_desc=JText::_('COM_JEXPORT_RULE_DESC');
$txt_url_scan=JText::_('COM_JEXPORT_URL_SCAN');

JToolBarHelper::title('JExport');
JToolBar::getInstance( 'toolbar' )->appendButton( 'Link', 'out-2', $txt_view_export, 'components/com_jexport/export', 300, 200 );
JToolBar::getInstance( 'toolbar' )->appendButton( 'Link', 'download', 'Download', JURI::base().'index.php?option=com_jexport&export=1', 300, 200 );

$config_path="components/com_jexport/config.json";
$config=fopen($config_path,"r");
$config=json_decode(fread($config,filesize($config_path)));

if(@$_GET["export"]=="1"){
	$path = explode("administrator",getcwd());
	unlink($path[0]."administrator/components/com_jexport/export.zip");

	// Get real path for our folder
	$rootPath = realpath($path[0]);

	// Initialize archive object
	$zip = new ZipArchive();
	$zip->open($path[0]."administrator/components/com_jexport/export.zip", ZipArchive::CREATE | ZipArchive::OVERWRITE);

	// Create recursive directory iterator
	/** @var SplFileInfo[] $files */
	$files = new RecursiveIteratorIterator(
	    new RecursiveDirectoryIterator($rootPath),
	    RecursiveIteratorIterator::LEAVES_ONLY
	);

	foreach ($files as $name => $file)
	{
	    // Skip directories (they would be added automatically)
	    if (!$file->isDir())
	    {
		// Get real and relative path for current file
		$filePath = $file->getRealPath();
		$relativePath = substr($filePath, strlen($rootPath) + 1);

		// Add current file to archive
		if(
			$relativePath != "configuration.php" &&
			$relativePath != "web.config.txt" &&
			$relativePath != "htaccess.txt" &&
			$relativePath != "index.php" &&
			$relativePath != "LICENSE.txt" &&
			$relativePath != "README.txt" &&
			$relativePath != "robots.txt"
		)
		$zip->addFile($filePath, $relativePath);
	    }
	}

	foreach (glob($path[0]."administrator/components/com_jexport/export/*.html") as $filePath) {
		$relativePath = explode("/", $filePath);
		$zip->addFile($filePath, $relativePath[count($relativePath)-1]);
	}

	// Zip archive will be created only after closing object
	$zip->close();
	
	$filename = "export.zip";
	$filepath = $path[0]."administrator/components/com_jexport/";

	// http headers for zip downloads
	header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Cache-Control: public");
	header("Content-Description: File Transfer");
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=\"".$filename."\"");
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".filesize($filepath.$filename));
	ob_end_flush();
	@readfile($filepath.$filename);
}
if(isset($_POST["start"])){
	$date1 = new dateTime();
	echo "<br /><strong>START ".$date1->format('Y-m-d H:i:s')."</strong><br /><br />";
	
	$config->rules=$_POST["rules"];
	$var=fopen($config_path,"w");
	fwrite($var, json_encode($config));

	$E=new Export();
	$E->init();
	$E->set_rules($_POST["rules"]);
	if($_POST["url_scan"]=="*")
		$E->Scan();
	else{
		$E->oneurl=true;
		$E->Scan($_POST["url_scan"]);
	}

	$date2 = new dateTime();
	echo "<br /><strong>STOP ".$date2->format('Y-m-d H:i:s')."</strong><br />";

	$time=$date1->diff($date2);
	echo "<br /><strong>TIME ".$time->format("%d days, %h ".$txt_hours." %i ".$txt_minuts." %s ".$txt_second)."</strong><br /><br />";
}
?>
<form method="post">
	<div class="cols">
		<div class="col"><textarea name="rules" id="rules"><?php echo $config->rules; ?></textarea></div>
		<div class="col"><?php echo $txt_rule_desc; ?></div>
	</div>
	<?php echo $txt_url_scan; ?> <input type="text" name="url_scan" value="*"><br />
	<input class="btn btn-small" type="submit" name="start" value="<?php echo $txt_export; ?>!">
</form>
