<?php
/*
* @name CB_k2forcb 1.0
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// Direct Acess not allowed!
// no direct access
defined('_JEXEC') or die(dirname(__FILE__).DS.'Restricted access');
require_once(JPATH_SITE.DS.'components'.DS.'com_k2'.DS.'helpers'.DS.'route.php');

class cbk2forcbTab extends cbTabHandler {
	function substr_delimiter($str,$start,$stop){
		$return=substr($str,strpos($str,$start));
		$return=substr($return,0,strpos($return,$stop));
		if(!strlen($return))
			return substr($str,strpos($str,$start));
		return $return;
	}
	function add_item($user_guest, $user){
		if($user_guest->id==$user->id){
			return '<span class="catItemAddLink">
<a class="modal" href="index.php?option=com_k2&view=item&task=add&tmpl=component" rel="{handler:\'iframe\',size:{x:990,y:650}}"> '.JText::_('K2_ADD_A_NEW_ITEM_IN_THIS_CATEGORY').' </a>
</span>';
		}else{
			return "";
		}
	}
	function getDisplayTab($tab,$user,$ui) {
		$database = JFactory::getDBO();
		$user_guest = JFactory::getUser();
		$document = JFactory::getDocument();
		$params = $this->params;
		$lang = JFactory::getLanguage();
		$lang->load('com_k2');

		$cat=$params->get('cat','1');
		$bg_color=$params->get('bg_color','555555');
		$size=$params->get('size','150');
		$margin=$params->get('margin','15');
		$padding=$params->get('padding','5');
		$span_cl=$params->get('span_cl','ffffff');
		$span_bg=$params->get('span_bg','000000');
		$span_bg=hexdec(substr($span_bg,0,2)).",".hexdec(substr($span_bg,2,2)).",".hexdec(substr($span_bg,4,2)).",".$params->get('span_opacity','0.6');

		//style css
$style = '#cb_k2_items {
	overflow:hidden;
}
#cb_k2_items.cb_k2_items_list a{
	background-color:#'.$bg_color.';
	background-size:100%;
	background-repeat:no-repeat;
	background-position:center;
	background-size:cover;
	width:'.$size.'px;
	height:'.$size.'px;
	margin:'.$margin.'px;
	float:left;
	display:block;
	text-decoration:none;
}
#cb_k2_items.cb_k2_items_list span{
	display:block;
	width:'.(100-($padding*2)).'%;
	color:#fff;
	text-align:center;
	color:#fff;
	padding:'.$padding.'%;
	color:#'.$span_cl.';
	background:rgba('.$span_bg.');
}
';
		$document->addStyleDeclaration( $style );

		$article=array();
		//se è stato cliccato un articolo lo cerco nel db
		if(strstr(JURI::current(),"page-k2-")){
			$urlid=explode("-",$this->substr_delimiter(JURI::current(),"page-k2-","/"));
			$database->setQuery('SELECT * FROM #__k2_items WHERE id='.$urlid[2]);
			$article = $database->loadAssocList();
		}

		//cerco se l'utente ha scritto articoli
		$database->setQuery('SELECT * FROM #__k2_items WHERE created_by='.$user->id.' AND catid='.$cat);
		$results = $database->loadAssocList();

		if(count($results)){
			//visualizza l'elenco degli articoli
			if(!count($article)){
				$return='<div id="cb_k2_items" class="cb_k2_items_list">';
				foreach($results as $res){
					$txt=$res["introtext"].$res["fulltext"];
					preg_match_all('/<img(.*?)src="(.*?)"(.*?)>/',$txt,$imgs);
					$background='';
					if(count($imgs[2])){
						$background='background-image:url('.JURI::base().$imgs[2][0].');';	
					}
					$url = K2HelperRoute::getItemRoute($res["id"].':'.urlencode($res["alias"]),$res["catid"].':'.urlencode($res["catalias"]));
					$return.='<a style="'.$background.'" href="'.$url.'"><span>'.$res["title"].'</span></a>';			
				}

				return $this->add_item($user_guest, $user).$return."</div>";
			}else{
			//visualizza l'articolo
				$return='<div id="cb_k2_items" class="cb_k2_items_detail">';

				$idk2 = $article[0]["id"];
				$http="";
				if(isset($_SERVER["REQUEST_SCHEME"]))
					$http=$_SERVER["REQUEST_SCHEME"]."://";

				$code=file_get_contents($http.$_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"]."?option=com_k2&view=item&id=".$idk2.":usera");
				$dom = new DOMDocument;
				@$dom->loadHTML($code);
				$main = $dom->getElementById('k2Container');

				$doc = new DOMDocument();
				foreach($main->childNodes as $child) {
				    $doc->appendChild($doc->importNode($child, true));
				}
				$return=$doc->saveHTML();

				if($user_guest->id==$user->id){
					$return = substr_replace($return, '<span class="itemEditLink">
		<a class="modal" href="index.php?option=com_k2&view=item&task=edit&cid='.$idk2.'&tmpl=component" rel="{handler:\'iframe\',size:{x:990,y:550}}"> '.JText::_('K2_EDIT_ITEM').' </a>
		</span>', strpos($return,'<h2 class="itemTitle">'), 0);
				}

				$return='<span class="catItemAddLink"><a href="'.substr(JURI::current(),0,strpos(JURI::current(),"/page-k2-")).'"> '.JText::_('JPREVIOUS').' </a></span>'.$return;

				return $return;
			}
		}

		return $this->add_item($user_guest, $user);
	}
}
?>
