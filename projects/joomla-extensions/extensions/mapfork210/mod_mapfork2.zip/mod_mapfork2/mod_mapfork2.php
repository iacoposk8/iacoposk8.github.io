<?php
/*
* @name mapfork2 1.0
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/
defined( '_JEXEC' ) or die( 'Restricted access' );

$address=$params->get('address', 1);
$city=$params->get('city', 1);
$zoom=$params->get('zoom', '8');
$database = JFactory::getDBO();

$req =JRequest::get( "request" );
$id=explode(":",@$req["id"]); 
@$id=$id[0];

if($req["view"]=="itemlist"){
	//$database->setQuery('SELECT * FROM #__k2_items WHERE catid='.$id);
	$session = JFactory::getSession();
	$query=$session->set( 'K2Search' );
	if($query==""){
		$query="SELECT i.*, c.name as categoryname,c.id as categoryid, c.alias as categoryalias, c.params as categoryparams FROM #__k2_items as i RIGHT JOIN #__k2_categories AS c ON c.id = i.catid WHERE i.published = 1 AND i.trash = 0 AND c.published = 1 AND c.trash = 0 AND i.extra_fields != '[]'";
	}
	if(strstr($query,"LIMIT")){
		$query=explode("LIMIT",$query);
		$query=trim($query[0]);
	}
	$database->setQuery($query);
}else if(isset($id) && @$id!=""){
	$database->setQuery('SELECT * FROM #__k2_items WHERE id='.$id);
}else{
	return true;
}
$results = $database->loadAssocList();
$coors_list=array();

$i=0; $max_lat=0; $min_lat=0; $max_lon=0; $min_lon=0;
foreach($results as $res){
	//cerco la via/indirizzo associata all'articolo corrente
	foreach(json_decode($res["extra_fields"]) as $field){
		if($field->id==$address){
			$val=$field->value;
		}
		if($field->id==$city){
			$val_c=$field->value;
		}
	}

	//se trovo l'indirizzo
	if($val!==""){
		//se non c'è la tabella delle coordinate, la creo
		$database->setQuery("SHOW TABLES LIKE '%k2_address_list%'");
		if(count($database->loadAssocList())==0){
			$query = "
				CREATE TABLE IF NOT EXISTS `#__k2_address_list` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`address` varchar(255) NOT NULL,
				`lat` varchar(255) NOT NULL,
				`lon` varchar(255) NOT NULL,
				PRIMARY KEY  (`id`)
				) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
			";
			$database->setQuery($query);
			$result = $database->query(); 
		}

		//cerco le coordinate dell'indirizzo
		$val=trim($val).", ".trim($val_c);
		$database->setQuery('SELECT * FROM #__k2_address_list WHERE address="'.$val.'"');
		$results = $database->loadAssocList();

		$link = '<a href="'.K2HelperRoute::getItemRoute($res["id"].':'.urlencode($res["alias"]),$res["catid"].':'.urlencode($res["catalias"])).'">'.$res["title"].'</a>';

		//se sono sul db le prelevo altrimenti le cerco e le inserisco
		if(count($results)){
			$coords=array("lat"=>$results[0]["lat"],"lon"=>$results[0]["lon"],"link"=>$link);
		}else{
			$data = json_decode(file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($val).'&key=AIzaSyCPCy5tZhxDCLKdYyWJIW6ejECFrTH7Y1s'));

			if(count($data->results)){
				$LNG=str_replace(",",".",$data->results[0]->geometry->location->lng);
				$LAT=str_replace(",",".",$data->results[0]->geometry->location->lat);
				$database->setQuery("INSERT INTO #__k2_address_list (address, lat, lon) VALUES (".$database->quote($val).",".$database->quote($LAT).",".$database->quote($LNG).")");
				$result = $database->query(); 
				$coords=array("lat"=>$LAT,"lon"=>$LNG,"link"=>$link);
			}
		}

		//se trovo la posizione
		if(isset($coords)){
			$coors_list[]=$coords;
			if($i==0){
				$max_lat=$coords["lat"];
				$min_lat=$coords["lat"];
				$max_lon=$coords["lon"];
				$min_lon=$coords["lon"];
			}
			if($coords["lat"]>$max_lat)
				$max_lat=$coords["lat"];
			if($coords["lon"]>$max_lon)
				$max_lon=$coords["lon"];
			if($coords["lat"]<$min_lat)
				$min_lat=$coords["lat"];
			if($coords["lon"]<$min_lon)
				$min_lon=$coords["lon"];
			$i++;
		}
	}
}

//se trovo la posizione
if(count($coors_list)){
$geocode="
<script type='text/javascript' src='http://maps.google.com/maps/api/js?sensor=false'></script>
<script type='text/javascript'>
var coors_list = ".json_encode($coors_list)."
var initialize = function() {
// fornisce latitudine e longitudine
var latlng = new google.maps.LatLng(parseFloat(".str_replace(",",".",(($max_lat+$min_lat)/2))."),parseFloat(".str_replace(",",".",(($max_lon+$min_lon)/2))."));
// imposta le opzioni di visualizzazione
var options = { zoom: ".$zoom.", center: latlng, mapTypeId: google.maps.MapTypeId.ROADMAP};
// crea l'oggetto mappa
var map = new google.maps.Map(document.getElementById('map'), options);

for(var i=0;i<coors_list.length;i++){
	coors_list[i].lat=parseFloat(coors_list[i].lat);
	coors_list[i].lon=parseFloat(coors_list[i].lon);
	mar_cord = new google.maps.LatLng(coors_list[i].lat,coors_list[i].lon);

	myinfowindow = new google.maps.InfoWindow({content: coors_list[i].link});
	marker = new google.maps.Marker({ position: mar_cord, map: map, infowindow: myinfowindow});
	
	google.maps.event.addListener(marker, 'click', function() {
		this.infowindow.open(map, this);
	});
}
}
window.onload = initialize;
</script>
<div id='map' style='width:300px; height:300px'></div>
";
	echo $geocode;
}
