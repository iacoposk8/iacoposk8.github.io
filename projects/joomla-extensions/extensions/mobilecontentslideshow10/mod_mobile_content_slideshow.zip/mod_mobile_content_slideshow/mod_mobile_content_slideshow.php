<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_mobile_content_slideshow
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

$document = JFactory::getDocument();
$document->addStyleSheet("modules/mod_mobile_content_slideshow/dist/css/slider-pro.min.css");
//$document->addScript("http://code.jquery.com/jquery-latest.min.js");
$document->addScript("modules/mod_mobile_content_slideshow/dist/js/jquery.sliderPro.min.js");
$document->addScript("modules/mod_mobile_content_slideshow/dist/js/slide.js");

$cat = $params->get('cat', '2');
$resolution = $params->get('resolution', '480');
$limit = $params->get('limit', '10');
$document->addStyleDeclaration('@media screen and (max-width: '.$resolution.'px) {.sp-white{top:10px !important;}.sp-black{display:none !important;}} .sp-thumbnail-container .sp-thumbnail{border-left:1px solid #222 !important; text-align:center !important; width:100% !important; min-height:30px !important; padding-top:5px !important;} .sp-thumbnail-container{margin-right:0px !important;}');

$database = JFactory::getDBO();
//id, catid, title, introtext, fulltext
$database->setQuery('SELECT * FROM #__content WHERE state=1 AND catid='.$cat.' ORDER BY created DESC LIMIT 0,'.$limit);
$results = $database->loadAssocList();
?>
<div id="mobile_content_slideshow" class="slider-pro" style="display:none;">
<?php
foreach ($results as $res){

//url articolo
$url=ContentHelperRoute::getArticleRoute($res["id"], $res["catid"]);

//preleva l'url dell'immagine
$txt=$res["introtext"]." ".$res["fulltext"];
preg_match_all('/<img(.*?)src="(.*?)"(.*?)>/',$txt,$img);
$img=$img[2][0];

//filtra il testo
$txt_filt=$txt;
$txt_filt=preg_replace('/\></','> <',$txt_filt);
$txt_filt=strip_tags($txt_filt);
$txt_filt=preg_replace('/\[(.*?)\]/','',$txt_filt);
$txt_filt=preg_replace('/\{(.*?)\}/','',$txt_filt);
$txt_filt=implode(' ', array_slice(explode(' ', $txt_filt), 0, 40));

if(str_replace(" ","",$txt_filt)=="")
	continue;
?>
	<div class="sp-slides">
		<div class="sp-slide">
			<img class="sp-image" src="modules/mod_mobile_content_slideshow/dist/css/images/blank.gif"
				data-src="<?php echo $img; ?>"
				data-retina="<?php echo $img; ?>"/>
			
			<p class="sp-layer sp-white sp-padding"
				data-horizontal="50" data-vertical="50"
				data-show-transition="left" data-hide-transition="up" data-show-delay="400" data-hide-delay="200">
				<a href="<?php echo $url; ?>"><?php echo $res["title"]; ?></a>
			</p>

			<p class="sp-layer sp-black sp-padding hide-small-screen"
				data-horizontal="50" data-vertical="100"
				data-show-transition="left" data-hide-transition="up" data-show-delay="600" data-hide-delay="100">
				<?php echo $txt_filt; ?>
			</p>
		</div>
	</div>
<?php
}
?>
	<div class="sp-thumbnails">
<?php
foreach ($results as $res){
?>
		<div class="sp-thumbnail">
			<div class="sp-thumbnail-title"><?php echo $res["title"]; ?></div>
		</div>
<?php
}
?>
	</div>
</div>
