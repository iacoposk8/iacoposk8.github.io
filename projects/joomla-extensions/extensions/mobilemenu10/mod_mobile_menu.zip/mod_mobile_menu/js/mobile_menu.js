( function($) {
	jQuery.noConflict();
	jQuery(document).ready(function($){
		var mobile_menu={
			button:$(".mobile_menu_button"),
			menu:$(".mobile_menu .menu")
		};
		var mobile_menu_animation=false;
		mobile_menu.button.click(function(){
			if(mobile_menu.menu.height()==0 && !mobile_menu_animation){
				mobile_menu_animation=true;

				mobile_menu.menu.css("height","auto");
				mobile_menu.menu.css("display","block");
				var height=menu=mobile_menu.menu.height();
				mobile_menu.menu.css("height","0px");

				mobile_menu.menu.animate({height:height+"px"},300,function(){mobile_menu_animation=false;});
			} else if(mobile_menu.menu.height()>0 && !mobile_menu_animation){
				mobile_menu_animation=true;
				mobile_menu.menu.animate({height:"0px"},300,function(){
					mobile_menu.menu.css("display","none");
					mobile_menu_animation=false;
				});
			}
		});
	});
} ) ( jQuery );
