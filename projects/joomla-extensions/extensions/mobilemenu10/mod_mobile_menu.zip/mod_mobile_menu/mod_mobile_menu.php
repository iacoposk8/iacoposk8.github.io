<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_mobile_menu
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

$document = JFactory::getDocument();
$document->addStyleSheet("modules/mod_mobile_menu/css/style.css");
$document->addScript("modules/mod_mobile_menu/js/mobile_menu.js");

// Include the syndicate functions only once
require_once __DIR__ . '/helper.php';

$list		= ModMobileMenuHelper::getList($params);
$base		= ModMobileMenuHelper::getBase($params);
$active		= ModMobileMenuHelper::getActive($params);
$active_id 	= $active->id;
$path		= $base->tree;

$showAll	= $params->get('showAllChildren');
$class_sfx	= htmlspecialchars($params->get('class_sfx'));

if (count($list))
{
	require JModuleHelper::getLayoutPath('mod_mobile_menu', $params->get('layout', 'default'));
}
