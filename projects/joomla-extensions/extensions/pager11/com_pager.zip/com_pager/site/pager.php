<?php
/*------------------------------------------------------------------------
# com_pager - Pager
# ------------------------------------------------------------------------
# Iacopo Guarneri
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.iacopo-guarneri.me
-------------------------------------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

	function replace_tag($str){
		preg_match_all("/{user\.(.*?)}/ims", $str, $user);
		if(count($user[1])){
			$juser = JFactory::getUser();
			foreach($user[1] as $us){ 
				$str=str_replace("{user.".$us."}",$juser->username,$str);
			}
		}
		preg_match_all("/{request\.(.*?)}/ims", $str, $rq);
		if(count($rq[1])){
			foreach($rq[1] as $us){ 
				$str=str_replace("{request.".$us."}",filter_var(JRequest::getVar($us), FILTER_SANITIZE_STRING),$str);
			}
		}
		return $str;
	}
	
	$app = JFactory::getApplication('site');
	$params =  & $app->getParams('com_pager');
	$page = $params->get( 'name_page', '');
	$val = replace_tag($params->get( 'id_val', ''));

	$database = JFactory::getDBO();

	//select page
    	$database->setQuery('SELECT * FROM #__pager_list_article WHERE name="'.$page.'" LIMIT 0,1');
    	$results = $database->loadAssocList();
	
	$select=replace_tag(str_replace("[value_menu]",$val,$results[0]['select_page']));
	$testo=replace_tag(stripslashes($results[0]['text_page']));

	$database->setQuery($select);
    	$results = $database->loadAssocList();

	$new_txts="";
	foreach($results as $result){
		$new_txt=$testo;

		preg_match_all("/\[COL\](.*?)\[\/COL\]/ims", $testo, $cols);
		foreach($cols[1] as $col){
			$new_txt=str_replace("[COL]".$col."[/COL]",$result[$col],$new_txt);
		}
		$new_txts.=$new_txt;
	}

	preg_match_all("/\[LIMIT\](.*?)\[\/LIMIT\]/ims", $new_txts, $limits);
	$limits=array_unique($limits[1]);
	foreach($limits as $limit){
		$pos = strpos($new_txts,"[LIMIT]".$limit."[/LIMIT]")+strlen("[LIMIT]".$limit."[/LIMIT]");
		if ($pos !== false) {
			$new_txts = substr($new_txts,0,$pos) . str_replace("[LIMIT]".$limit."[/LIMIT]",'',substr($new_txts,$pos));
		}
	}

	echo str_replace("[LIMIT]","",str_replace("[/LIMIT]","",$new_txts));
?>
