<?php
/*
* @name searchfork2 1.0
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

class plgContentsearchfork2 extends JPlugin
{
	function get_fields(){
		$database = JFactory::getDBO();
		$lists=$this->params->get("name","1");
		$req =JRequest::get( "request" );

		$id=$req["id"];
		if(strstr($id,":")){
			$id=explode(":",$id);
			$id=$id[0];
		}

		$ar=array();
		$database->setQuery('SELECT * FROM #__k2_categories WHERE id='.$id);
		$results = $database->loadAssocList();
		$database->setQuery('SELECT * FROM #__k2_extra_fields WHERE `group`='.$results[0]["extraFieldsGroup"].' AND published=1 ORDER BY ordering ASC');

		foreach($database->loadAssocList() as $res){
			if(in_array($res["id"], $lists))
				$ar[]=$res;
		}
		return $ar;
	}
	function get_type($id){
		$database = JFactory::getDBO();
		$database->setQuery("SELECT type FROM #__k2_extra_fields WHERE id=".$id);
		$type=$database->loadAssocList();
		return $type[0]["type"];
	}
	function onK2BeforeSetQuery(&$query){
		if(JRequest::getVar("k2search_submit", '', 'post')=="" || strstr($query,"SELECT COUNT(*) FROM"))
			return true;

		$database = JFactory::getDBO();
		$database->setQuery($query);

		$Q="";
		foreach($database->loadAssocList() as $row){
			if(!count(@json_decode($row["extra_fields"])))
				continue;
			foreach(json_decode($row["extra_fields"]) as $ef){
				$val = JRequest::getVar("k2search_".$ef->id, '', 'post');
				if($val!=""){
					$type=$this->get_type($ef->id);
					if(($type=="textfield" || $type=="textarea" || $type=="link" || $type=="date") && strstr($ef->value,$val))
						$Q.="i.id=".$row["id"]." OR ";
					if($type=="labels" || $type=="select" || $type=="multipleSelect" || $type=="radio"){
						$items=$ef->value;
						if($type=="labels")
							$items=explode(",",$ef->value);
						foreach($items as $item){
							if(strstr(trim($items),$val)){
								$Q.="i.id=".$row["id"]." OR ";
								break;
							}
						}
					}
				}
			}
		}
		
		if($Q!="")
			$query=preg_replace('/WHERE(.*?)ORDER/',"WHERE ".substr($Q,0,-4)." ORDER",$query);

		$session = JFactory::getSession();
		$session->set( 'K2Search', $query );

		return true;
	}
	function onContentPrepare( $context, &$article, &$params, $page = 0)
	{ 
		if(!function_exists('is_cat')) {
			function is_cat(){
				$data =JRequest::get( "request" );
				if($data["view"]=="itemlist")
					return true;
				return false;
			}
		}

		//se c'è stata una categoria prima dell'articolo esci subito
		if($context=="com_k2.itemlist" && is_cat()){
			return true;
		}

		if(is_cat()){
			$database = JFactory::getDBO();

			$form='<form id="k2search" method="post"><table>';
			foreach($this->get_fields() as $res){
				$value=json_decode($res["value"]);

				$form.='<tr><td><label>'.$res["name"].'</label></td><td>';
				if($res["type"]=="textfield" || $res["type"]=="textarea" || $res["type"]=="link" || $res["type"]=="labels"){
					$form.='<input type="text" name="k2search_'.$res["id"].'" value="'.$value[0]->value.'">';
				}
				$multiple="";
				if($res["type"]=="multipleSelect")
					$multiple=" multiple";
				if($res["type"]=="select" || $res["type"]=="multipleSelect" || $res["type"]=="radio"){
					$form.='<select name="k2search_'.$res["id"].'"'.$multiple.'><option value=""></option>';
					foreach($value as $val)
						$form.='<option value="'.$val->value.'">'.$val->name.'</option>';
					$form.='</select>';
				}
				if($res["type"]=="date"){
					$form.=JHtml::_('calendar', $value[0]->value, "k2search_".$res["id"], "k2searchmap");
				}
				$form.='</td></tr>';
			}
			$form.='<tr><td></td><td style="text-align:right;"><input type="submit" value="search" name="k2search_submit"></td></tr></table></form>';
			$article->text=$form.$article->text;
		}

		return true;
	}
}
