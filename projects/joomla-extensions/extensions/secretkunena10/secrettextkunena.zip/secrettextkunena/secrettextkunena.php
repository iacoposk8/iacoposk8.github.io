<?php
/*
* @name Secret text for kunena 1.0
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// No direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

class plgKunenasecrettextkunena extends JPlugin
{
	public function onKunenaBbcodeEditorInit($editor)
    	{
        	$this->loadLanguage();
        	$btn = new KunenaBbCodeEditorButton('secret', 'secret', 'secret', 'PLG_KUNENASECRET_TITLE', 'PLG_KUNENASECRET_BTN_ALT');
        	$btn->addWrapSelectionAction();
        	$editor->insertElement($btn, 'after', 'code');

        	$document = JFactory::getDocument();

        	$document->addStyleDeclaration("#Kunena #kbbcode-toolbar #secret {
            		background-image: url(\"" . JURI::base(true) . "/plugins/kunena/secrettextkunena/images/lock.png\");
        	}");

    	}

    	public function onKunenaBbcodeConstruct($bbcode)
    	{
		$this->loadLanguage();
		$session = JFactory::getSession();
		$session->set( 'KUNENASECRET_TITLE', JText::_('PLG_KUNENASECRET_TITLE'));
		$session->set( 'KUNENASECRET_ERROR', JText::_('PLG_KUNENASECRET_ERROR'));

        	$bbcode->AddRule('secret', array(
                	'mode' => BBCODE_MODE_CALLBACK,
                	'method' => 'plgKunenasecrettextkunena::onsecret',
                	'allow' => array('type' => '/^[\w]*$/',),
                	'allow_in' => array('listitem', 'block', 'columns'),
                	'content' => BBCODE_VERBATIM,
			'before_tag' => "sns",
                	'after_tag' => "sn",
                	'before_endtag' => "sn",
                	'after_endtag' => "sns",
                	'plain_start' => "\n",
                	'plain_end' => "\n")
        	);
        	return true;
    	}

	static public function onsecret($bbcode, $action, $name, $default, $params, $content)
    	{
		$session = JFactory::getSession();
		$document = JFactory::getDocument();
		$document->addStyleSheet(JURI::base(true) . '/plugins/kunena/secrettextkunena/style.css');
		$style = '#example {
			border-color:#' . $bordercolor . ';
			}';
		$document->addStyleDeclaration( $style );
		
		if ($action == BBCODE_CHECK) {
            		$bbcode->autolink_disable = 1;
            		return true;
        	}

        	$bbcode->autolink_disable = 0;

        	$pconf = JPluginHelper::getPlugin('kunena', 'secrettextkunena');
        	$pconf = json_decode($pconf->params);
		$allow_groups = $pconf->secret_text_usergroup;
        	$content_urlencoded = html_entity_decode($content);

		$user = JFactory::getUser();
		$groups = $user->get('groups');

		$html=array("<div class='kunenasecret_title'>".$session->get( 'KUNENASECRET_TITLE')."</div><div class='kunenasecret_desc'>","</div>");
	
		foreach($allow_groups as $allow){
			foreach($groups as $group){
				if($group==$allow){
					return $html[0].$content_urlencoded.$html[1];
				}
			}
		}

		return $html[0].$session->get( 'KUNENASECRET_ERROR').$html[1];
    	}
}

