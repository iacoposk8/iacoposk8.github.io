<?php
/**
* @name Select to social.
* @version 1.0
* @package Select to social
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
**/

defined( '_JEXEC') or ( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

jimport('joomla.plugin.plugin');

class plgSystemselecttosocial extends JPlugin
{
	function onBeforeRender()
	{
		if(!strstr(JURI::base(),"administrator")){
			$sites=$this->params->get('sites', 'tw');
			
			$document = JFactory::getDocument();
			$document->addStyleDeclaration('
				#selecttosocial{
					position:absolute;
					background:#000;
					background:rgba(0,0,0,0.8);
					padding:1px 5px;
					border-radius:4px;
				}
				#selecttosocial::after{
					content: "";
					position: absolute;
					left: 50%;
					top: 100%;
					width: 0;
					height: 0;
					border-left: 12px solid transparent;
					border-right: 12px solid transparent;
					border-top: 12px solid rgba(0,0,0,0.8);
					clear: both;
					margin-left:-12px;
				}
				#selecttosocial a{
					background-image:url('.JURI::base().'plugins/system/selecttosocial/icons.png);
					width:30px;
					height:30px;
					display:inline-block;
					background-size: 290px auto;
					margin:0 3px;
				}
				#selecttosocial_tw{
					background-position:0 -35px;
				}
				#selecttosocial_fb{
					background-position:-64px -34px;
				}
				#selecttosocial_gp{
					background-position:-134px -35px;
				}
				#selecttosocial_pi{
					background-position:-199px -35px;
				}
				#selecttosocial_in{
					background-position:-260px -35px;
				}
			');

			$document->addScriptDeclaration('
				function getSelectionText() {
					var text = "";
					if (window.getSelection) {
						text = window.getSelection().toString();
					} else if (document.selection && document.selection.type != "Control") {
						text = document.selection.createRange().text;
					}
					return text;
				}

				jQuery(document).ready(function($){
					var social_links={
						"tw":"https://twitter.com/intent/tweet?text=[TEXT]&url=[URL]",
						"fb":"http://www.facebook.com/sharer/sharer.php?u=[URL]",
						"gp":"https://plus.google.com/share?url=[URL]",
						"pi":"http://pinterest.com/pin/create/button/?url=[URL]&description=[TEXT]",
						"in":"http://www.linkedin.com/shareArticle?mini=true&url=[URL]&title=[URL]&summary=[TEXT]&source=[URL]"
					};
					var social_links_allow='.json_encode($sites).';
					$("*").mouseup(function (e) {
						$("#selecttosocial").remove();
					});
					$("p, div").mouseup(function (e) {
						e.stopImmediatePropagation();
						var txt_sel=getSelectionText();
						if (txt_sel != "") {
							$("body").append("<div id=\"selecttosocial\"></div>");
							for(i in social_links){
								if(social_links_allow.indexOf(i)!=-1){
									var new_url=social_links[i].replace("[TEXT]",encodeURI(txt_sel));
									new_url=new_url.replace("[URL]",encodeURI(document.URL));
									$("#selecttosocial").append("<a id=\"selecttosocial_"+i+"\" target=\"_blank\" href=\""+new_url+"\"></a>");
								}
							}
							$("#selecttosocial").css("top",e.pageY-$("#selecttosocial").height()-25+"px").css("left",e.pageX-($("#selecttosocial").width()/2)+"px");
						}
					});
					$(document).delegate("#selecttosocial a","mouseup",function(e){
						window.open($(this).attr("href"), "_blank"); 
					});
				});
			');
		}
	}
}
?>
