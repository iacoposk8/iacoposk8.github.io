<?php
/*
* @name slideshowminutes 1.0
* Created By Guarneri Iacopo
* http://www.the-html-tool.com/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

echo"<script>";
echo"var transition='".$params->get('transition', 200)."'; ";
echo"var dir='".$params->get('dir', 'images/slideshow')."'; ";
echo"var est='".$params->get('est', '.jpg')."'; ";
echo"var prefix='".$params->get('prefix', '')."'; ";

//creo un array di 60 posizioni tutte col cancelletto (link vuoti)
echo"var link=[";
for($i=0;$i<=59;$i++){
	echo"'#',";
}
echo"];
";

$links=explode(",",$params->get('link', ''));
foreach($links as $link){
	$link=explode("[link]",$link);
	echo "link[".trim($link[0])."]='".trim($link[1])."';";
}

echo"</script>";
?>

<a id="slideShowMinutes_a" target="blank"><img id="slideShowMinutes_img"></a>
<div id="slideShowMinutes_time"></div>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script>
( function($) {
jQuery.noConflict();
jQuery(document).ready(function($){

function slideShowMinutes_img(){
	var date = new Date();
	var hou=date.getHours();
	var min=date.getMinutes();
	var sec=date.getSeconds();

	function slide_image(M){
		$("#slideShowMinutes_img").animate({opacity:0},transition,function(){
			$("#slideShowMinutes_img").attr("src","<?php echo JURI::base(); ?>"+dir+"/"+prefix+M+est);
			$("#slideShowMinutes_a").attr("href",link[M]);
			$("#slideShowMinutes_img").animate({opacity:1},transition);
		});
	}
	slide_image(min);

	var time=setInterval(function(){
		sec++; if(sec>59){sec=0;}
		if(sec==0){
			min++; if(min>59){min=0;}
			if(min==0){hou++; if(hou>23){hou=0;}}
			slide_image(min);
		}
		$("#slideShowMinutes_time").html(hou+":"+min+":"+sec);
	},1000);
}
slideShowMinutes_img();

});
} ) ( jQuery );
</script>
<br /><br /><span style="font-size:10px;">Powered by <a href="http://www.the-html-tool.com/" target="_blank">The Html Tool</a></span>
