<?php
/**
* @name We hate spam.
* @version 1.0
* @package We Hate Spam
* Created By Guarneri Iacopo
* http://www.iacopo-guarneri.me/
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
**/

defined( '_JEXEC') or ( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

jimport('joomla.plugin.plugin');
require_once(JPATH_SITE.DS.'plugins'.DS.'system'.DS.'we_hate_spam'.DS.'SpambotCheck'.DS.'SpambotCheckImpl.php');

class plgSystemwe_hate_spam extends JPlugin
{
	function onAfterRoute()
	{
		$option=JRequest::getVar('option', '', 'post');
		$task=JRequest::getVar('task', '', 'post');

		$this->loadLanguage();

		if(
			($option=="com_comprofiler" && $task=="saveregisters") || 
			($option=="com_users" && $task=="registration.register") ||
			($option=="com_contact" && $task=="contact.submit")
		){

			if($option=="com_comprofiler"){
				$email=JRequest::getVar('email', '', 'post');
				$username=JRequest::getVar('username', '', 'post');
			}
			if($option=="com_users"){
				$post = JRequest::get('jform', '', 'post');
				$email = $post['jform']['email1'];
				$username = $post['jform']['username'];
			}
			if($option=="com_contact"){
				$post = JRequest::get('jform', '', 'post');
				$email = $post['jform']['contact_email'];
				$username = $post['jform']['contact_name'];
			}
		
			$user = array( 
				"fullname" => $username,
				"username" => $username,
				"email" => $email
			 );
			 
			$spamString = "";
			if($this->_isSpammer($user, $spamString)){
				$this->_sendMailToAdmin($user, $spamString, "");

				$message  = JText::_( 'USER_REGISTRATION_SPAM_TXT' );
				$app = JFactory::getApplication();
				$app->redirect('index.php', $message, "error");
				$app->close();
				return false;
			}
		}  
	}	
	
	/**
	 * Method check if the user specified is a spammer.
	 *
	 * @param 	array		holds the user data
	 * @param 	string		hold the raw string returned by "check_spammers_plain.php" 
	 * 
	 * @return boolean True if user is a spammer and False if he isn't. 
	 */
	function _isSpammer($user, &$spamString)
	{	
		//AVack:: 20101111 don't check admins
		if (!userIsAdmin($user))
		{
			$fspamcheck = checkSpambots($this->params, $user['email'], $_SERVER['REMOTE_ADDR'], $user['username']);
			if ($fspamcheck == false || strlen($fspamcheck) == 0 || strpos($fspamcheck, "SPAMBOT_TRUE") === false)	
			{
				// not a spammer
				$spamString = "";
				return false;
			}

			// if we get here we have to deal with a spammer		
			$spamString = $fspamcheck;
			return true;
		}
		return false;
	}
	
	
	/**
	 * Send an e-mail about the failed login/register attempt to all admins.
	 *
	 * @param 	array		holds the user data
	 * @param 	string		hold the raw string returned by "check_spammers_plain.php"
	 * @param 	string		string added to the e-mail subject 
	 * 
	 * @return boolean True if user is a spammer and False if he isn't. 
	 */
	function _sendMailToAdmin(&$user, &$spamString, $subjectAddString)
	{	
		if (!$this->params->get('spbot_email_notifications', 1))	{
			// -> NO admin notifications
			return;
		}
		$name  = $user['fullname'];
		$username = $user['username'];
		$email = $user['email'];		
		$sPostersIP = $_SERVER['REMOTE_ADDR'];

		$app = JFactory::getApplication();
		$sitename 		= $app->getCfg( 'sitename' );
		$mailfrom 		= $app->getCfg( 'mailfrom' );
		$fromname 		= $app->getCfg( 'fromname' );

		//get all super administrator
		$db		=& JFactory::getDBO();
		$query = 'SELECT u.name AS name, u.email AS email, u.sendEmail AS sendEmail FROM `#__users` AS u LEFT JOIN `#__user_usergroup_map` AS map ON map.user_id = u.id LEFT JOIN `#__usergroups` AS g ON map.group_id = g.id WHERE g.title = "Super Users"';
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		
		// Send notification to all administrators
		$subject2 = sprintf ( JText::_( 'ACCOUNT_DETAILS_FOR_TXT' ), $name, $sitename) . $subjectAddString;
		$subject2 = html_entity_decode($subject2, ENT_QUOTES);

		// get superadministrators id
		foreach ( $rows as $row )
		{
			if ($row->sendEmail)
			{
				$message2 = sprintf ( JText::_( SEND_EMAIL_TO_ADMIN_TXT ), $row->name, $sitename, $name, $email, $username, $sPostersIP, $spamString);
				$message2 = html_entity_decode($message2, ENT_QUOTES);
				JUtility::sendMail($mailfrom, $fromname, $row->email, $subject2, $message2);
			}
		} 
	}	
}
?>
