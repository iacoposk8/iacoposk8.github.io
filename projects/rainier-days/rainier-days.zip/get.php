<?php
	ini_set('max_execution_time', 0);
	function get_web_page( $url ){
		$options = array(
			CURLOPT_RETURNTRANSFER => true,     // return web page
			CURLOPT_HEADER         => false,    // don't return headers
			CURLOPT_FOLLOWLOCATION => true,     // follow redirects
			CURLOPT_ENCODING       => "",       // handle all encodings
			CURLOPT_USERAGENT      => "spider", // who am i
			CURLOPT_AUTOREFERER    => true,     // set referer on redirect
			CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
			CURLOPT_TIMEOUT        => 120,      // timeout on response
			CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
			CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
		);

		$ch      = curl_init( $url );
		curl_setopt_array( $ch, $options );
		$content = curl_exec( $ch );
		$err     = curl_errno( $ch );
		$errmsg  = curl_error( $ch );
		$header  = curl_getinfo( $ch );
		curl_close( $ch );

		$header['errno']   = $err;
		$header['errmsg']  = $errmsg;
		$header['content'] = $content;
		return $content;
	}
	function filter($str){
		$str = str_replace("&deg;","°",$str);
		return $str;
	}
	function symbol($str){
		$ret = "";
		preg_match_all('/alt="(.*?)"/ims', $str, $matchs, PREG_SET_ORDER, 0);
		foreach($matchs as $match){
			$ret .= $match[1].",";
		}
		if($ret != "")
			return substr($ret,0,-1);		
		return $ret;
	}
	
	$db = new PDO('sqlite:meteo.db');

	$mesi = array("Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre");
	for($anno=2013;$anno<=2017;$anno++){
		foreach($mesi as $mese){
			$html = get_web_page("https://www.ilmeteo.it/portale/archivio-meteo/Varese/".$anno."/".$mese);
			preg_match_all('/<div id="mainc" class="main-cell">(.*?)Medie e totali mensili/ims', $html, $main, PREG_SET_ORDER, 0);
			if(!isset($main[0])){
				var_dump($html);
				die("<br /><br />".$mese." ".$anno);
			}
			preg_match_all('/<table(.*?)>(.*?)<\/table>/ims', $main[0][1], $tables, PREG_SET_ORDER, 0);
			preg_match_all('/<tr(.*?)>(.*?)<\/tr>/ims', $tables[2][2], $trs, PREG_SET_ORDER, 0);
			foreach($trs as $trf){
				$tr = $trf[2];

				preg_match_all('/<td(.*?)>(.*?)<\/td>/ims', $tr, $tds, PREG_SET_ORDER, 0);
				if(count($tds)){
					$row = array($anno, $mese, filter($tds[0][2]), filter($tds[1][2]), filter($tds[2][2]), filter($tds[3][2]), filter($tds[4][2]), filter($tds[5][2]), filter($tds[6][2]), filter($tds[7][2]), symbol($tds[8][2]));
					$sth = $db->prepare("SELECT * FROM list WHERE anno = ? AND mese = ? AND giorno = ?");
					$sth->execute(array($anno, $mese, filter($tds[0][2])));
					$select = $sth->fetchAll();
					if(!count($select)){
						$qry = $db->prepare('INSERT INTO list (anno, mese, giorno, tmedia, tmin, tmax, precip, umidita, ventomax, raffica, fenomeni) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
						$qry->execute($row);
					}
				}
			}
		}
	}