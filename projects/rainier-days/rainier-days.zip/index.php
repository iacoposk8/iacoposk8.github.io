<?php
	function get_web_page( $url ){
		$options = array(
			CURLOPT_RETURNTRANSFER => true,     // return web page
			CURLOPT_HEADER         => false,    // don't return headers
			CURLOPT_FOLLOWLOCATION => true,     // follow redirects
			CURLOPT_ENCODING       => "",       // handle all encodings
			CURLOPT_USERAGENT      => "spider", // who am i
			CURLOPT_AUTOREFERER    => true,     // set referer on redirect
			CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
			CURLOPT_TIMEOUT        => 120,      // timeout on response
			CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
			CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
		);

		$ch      = curl_init( $url );
		curl_setopt_array( $ch, $options );
		$content = curl_exec( $ch );
		$err     = curl_errno( $ch );
		$errmsg  = curl_error( $ch );
		$header  = curl_getinfo( $ch );
		curl_close( $ch );

		$header['errno']   = $err;
		$header['errmsg']  = $errmsg;
		$header['content'] = $content;
		return $content;
	}
	
	$db = new PDO('sqlite:meteo.db');

	$max = 0;
	$calc = array("Gennaio"=>array(), "Febbraio"=>array(), "Marzo"=>array(), "Aprile"=>array(), "Maggio"=>array(), "Giugno"=>array(), "Luglio"=>array(), "Agosto"=>array(), "Settembre"=>array(), "Ottobre"=>array(), "Novembre"=>array(), "Dicembre"=>array());
	$mesi = array("Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre");
	foreach($mesi as $mese){
		$sth = $db->prepare("SELECT * FROM list WHERE mese = ? ORDER BY giorno ASC");
		$sth->execute(array($mese));
		foreach($sth->fetchAll() as $res){
			if(strstr($res["fenomeni"],"pioggia")){
				if(!isset($calc[$mese][$res["giorno"]]))
					$calc[$mese][$res["giorno"]] = 0;
				else
					$calc[$mese][$res["giorno"]]++;
				
				if($calc[$mese][$res["giorno"]] > $max)
					$max = $calc[$mese][$res["giorno"]];
			}
		}
	}
	
	$bar_width = 4;
	foreach($calc as $keym => $mese){
		foreach($mese as $keyg => $giorno){
			$color = 255-(($giorno/$max)*255);
			echo '<div title="'.$keyg.' '.$keym.' ('.$giorno.')" style="height:300px; width:'.$bar_width.'px; float:left; background:rgb('.$color.','.$color.','.$color.');"></div>';
		}
	}
	
	echo '<div style="width:100%; clear:left;"></div>';
	
	$date = new DateTime();
	$current_day = $date->format('d');
	$current_mon = $mesi[$date->format('m')-1];
	
	$exit = false;
	foreach($calc as $keym => $mese){
		foreach($mese as $keyg => $giorno){
			$color = "fff";
			if($current_mon == $keym && $current_day == $keyg)
				$color = "0f0";
			echo '<div title="'.$keyg.' '.$keym.'" style="height:300px; width:'.$bar_width.'px; float:left; background:#'.$color.';"></div>';
			
			if($current_mon == $keym && $current_day == $keyg){
				$exit = true;
				break;
			}
		}
		
		if($exit)
			break;
	}
	
	$next = get_web_page("https://www.ilmeteo.it/meteo/Varese");
	preg_match_all('/<ul(.*?)id="daytabs"(.*?)>(.*?)<\/ul>/ims', $next, $ul, PREG_SET_ORDER, 0);
	foreach($ul as $U){
		preg_match_all('/<li(.*?)>(.*?)<\/li>/ims', $U[3], $li, PREG_SET_ORDER, 0);
		foreach($li as $L){
			preg_match_all('/<span class="s ss(.*?)"/ims', $L[0], $nw, PREG_SET_ORDER, 0);
			
			if(isset($nw[0])){
				if($nw[0][1]=="3" || $nw[0][1]=="1" || $nw[0][1]=="8" || $nw[0][1]=="4")
					$color = "fff";
				else if($nw[0][1]=="5")
					$color = "ccc";
				else if($nw[0][1]=="9") //1 goccia
					$color = "aaa";
				else if($nw[0][1]=="16")
					$color = "333";
				else if($nw[0][1]=="13") //2 gocce fulmine
					$color = "000";
				else
					die($nw[0][1]);
				
				echo '<div style="height:300px; width:'.$bar_width.'px; float:left; background:#'.$color.';"></div>';
			}
		}
	}